﻿using Crossover.Core.Entity;
using System.Collections.Generic;

namespace Crossover.Core.IService
{
    public interface IRegisterService
    {
        Application Register(Application entity);
    }
}
