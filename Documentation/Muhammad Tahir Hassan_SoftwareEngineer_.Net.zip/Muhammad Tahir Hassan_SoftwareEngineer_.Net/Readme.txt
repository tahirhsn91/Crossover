Requirments
1- Visual Studio 2015.
2- Sql Server 2008


Step To Configure Project
1- Rebuild the Solution and Restore NuGet Packages.
2- Open Web.config in Crossover.API.
3- Adjust appSettings variables accrodingly.
	RequestExpiry -> Maximum expiry time of every request processed by server.
	RateLimit -> Maximum request handled by server.
	SpecialWaiting -> time taken by server if ratelimit exceeded.
4- Adjust connectionStrings variable accordingly.
	CrossoverEntities -> connection string used in the application.
		data source -> database server name.
		initial catalog -> database name.
		integrated security -> if using windowns authentication.
		User Id -> if using SQL authentication, add user name of sql server.
		Password -> if using SQL authentication, add Password of sql server.